import turtle
import time
import random
import winsound

winsound.PlaySound("Song1.wav", winsound.SND_ASYNC)
    
delay = 0.1 #this is to stop the turtle head boosting off

#score
score = 0
high_score = 0

# setup the screen
wn = turtle.Screen()
wn.title("Snake Game")
wn.bgcolor("dark green")
wn.setup(width=600, height=600)
wn.tracer(0) #turns off screen updates

# the Snake head using a turtle object
head = turtle.Turtle()
head.speed(0) # not speed but anamation speed
head.shape("square")
head.color("black")
head.penup() # the turtle modual wants to draw lines we do not so if we lift the pen up it will not draw a line
head.goto(0,0) # starts in center of screen
head.direction = "stop" # direction on play

# border1
border1 = turtle.Turtle()
border1.shape("square")
border1.color("black")
border1.turtlesize(40,5)
border1.penup()
border1.goto(350,0)

border1 = turtle.Turtle()
border1.shape("square")
border1.color("black")
border1.turtlesize(40,5)
border1.penup()
border1.goto(-350,0)

border1 = turtle.Turtle()
border1.shape("square")
border1.color("black")
border1.turtlesize(5,40)
border1.penup()
border1.goto(0,350)

border1 = turtle.Turtle()
border1.shape("square")
border1.color("black")
border1.turtlesize(5,40)
border1.penup()
border1.goto(0,-350)


#Snake Food
food = turtle.Turtle()
food.speed(0) 
food.shape("square")
food.color("light green")
food.penup() 
x = random.randint(-290, 290)
y = random.randint(20, 270)
food.goto(x,y) 

segments = []

# pen

pen = turtle.Turtle()
pen.speed(0)
pen.shape("square")
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 260)
pen.write("Score: 0         High Score: 0", align="center", font=("Courier", 24, "normal"))

# Functions

#music Selector
def Song1():
    winsound.PlaySound("Song1.wav", winsound.SND_ASYNC)

def Song2():
    winsound.PlaySound("Song2.wav", winsound.SND_ASYNC)

def Song3():
    winsound.PlaySound("Song3.wav", winsound.SND_ASYNC)

def Song4():
    winsound.PlaySound("Song4.wav", winsound.SND_ASYNC)

#movement fuinctions
def go_up():
    if head.direction != "down":
        head.direction = "up"

def go_down():
    if head.direction != "up":
        head.direction = "down"
    
def go_left():
    if head.direction != "right":
        head.direction = "left"

def go_right():
    if head.direction != "left":
        head.direction = "right"
    
def move():
    if head.direction == "up":
        y = head.ycor()
        head.sety(y + 20)

    if head.direction == "down":
        y = head.ycor()
        head.sety(y - 20)

    if head.direction == "left":
        x = head.xcor()
        head.setx(x - 20)
        
    if head.direction == "right":
        x = head.xcor()
        head.setx(x + 20)

#Key Bindings
wn.listen() # telling the window to listen for key press's
wn.onkeypress (go_up, "w")
wn.onkeypress (go_down, "s")
wn.onkeypress (go_left, "a")
wn.onkeypress (go_right, "d")
wn.onkeypress (Song1, "1")
wn.onkeypress (Song2, "2")
wn.onkeypress (Song3, "3")
wn.onkeypress (Song4, "4")

# main game loop
while True:
    
    

    wn.update()


    #check for border collision
    if head.xcor()>280 or head.xcor()<-280 or head.ycor()>280 or head.ycor()<-280:
        winsound.PlaySound("Game Over.wav", winsound.SND_ASYNC)
        time.sleep(3)
        head.goto(0,0)
        head.direction = "stop"
        delay = 0.1
        winsound.PlaySound("Song1.wav", winsound.SND_ASYNC)

        #hide the segments
        for segment in segments:
            segment.goto(1000, 1000)

        segments.clear()

        #reset score
        score = 0

        pen.clear()
        pen.write("Score: {}      High Score: {}".format(score, high_score), align="center", font=("Courier", 24, "normal"))

    #check for colission with food
    if head.distance(food) < 20:
        x = random.randint(-290, 290)
        y = random.randint(-290, 270)
        food.goto(x,y)

        if delay > 0.035:
            delay -= 0.0035

        
        # increase the score
        score += 10

        if score > high_score:
            high_score = score
            
        pen.clear()
        pen.write("Score: {}      High Score: {}".format(score, high_score), align="center", font=("Courier", 24, "normal"))

        # add segment
        new_segment = turtle.Turtle()
        new_segment.speed(0) # anamation speed
        new_segment.shape("square")
        new_segment.color("grey")
        new_segment.penup()
        segments.append(new_segment)

    for index in range(len(segments)-1, 0, -1):
        x = segments[index -1].xcor()
        y = segments[index -1].ycor()
        segments[index].goto(x, y)

    if len(segments) > 0:
        x = head.xcor()
        y = head.ycor()
        segments[0].goto(x,y)
            
    move()

    # check for head collisions
    for segment in segments:
        if segment.distance(head) < 20:
            winsound.PlaySound("Game Over.wav", winsound.SND_ASYNC)
            time.sleep(3)
            head.goto(0,0)
            head.direction = "stop"
            delay = 0.1
            winsound.PlaySound("Song1.wav", winsound.SND_ASYNC)

            #hide the segments
            for segment in segments:
                segment.goto(1000, 1000)

            segments.clear()

            score = 0

            pen.clear()
            pen.write("Score: {}      High Score: {}".format(score, high_score), align="center", font=("Courier", 24, "normal"))

    
    time.sleep(delay) # this will activate the delay 

wn.mainloop()
