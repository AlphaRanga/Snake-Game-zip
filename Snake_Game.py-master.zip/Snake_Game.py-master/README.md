# Snake_Game.py
Simple python snake game.

Simply put all downloaded files in the same folder and run the SNake Game
